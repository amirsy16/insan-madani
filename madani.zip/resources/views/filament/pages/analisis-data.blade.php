<x-filament-panels::page>
    {{-- Header widgets akan otomatis dirender oleh Filament --}}
    
    {{-- Konten utama halaman --}}
    <div class="space-y-6">
        {{-- Konten custom jika diperlukan dapat ditambahkan di sini --}}
    </div>
    
    {{-- Footer widgets akan otomatis dirender oleh Filament --}}
</x-filament-panels::page>