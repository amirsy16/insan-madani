<?php

namespace App\Filament\Resources\PengaturanHakAmilResource\Pages;

use App\Filament\Resources\PengaturanHakAmilResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePengaturanHakAmil extends CreateRecord
{
    protected static string $resource = PengaturanHakAmilResource::class;
}
