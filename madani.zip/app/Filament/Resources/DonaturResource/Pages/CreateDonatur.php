<?php

namespace App\Filament\Resources\DonaturResource\Pages;

use App\Filament\Resources\DonaturResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDonatur extends CreateRecord
{
    protected static string $resource = DonaturResource::class;

    protected function getRedirectUrl(): string{
        return $this->getResource()::getUrl('index');
        }
}
